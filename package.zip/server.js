const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);

const PORT = 3001;

// Start the server
http.listen(PORT, () => {
    console.log(`Listening on port ${PORT}`);
});

// Serve static files
app.use(express.static(__dirname + '/public'));

// Serve the main HTML file
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

// Socket.IO setup
io.on('connection', (socket) => {
    console.log('Connected...');

    // Listen for incoming messages and broadcast them to all other clients
    socket.on('message', (msg) => {
        // Broadcast message to all other clients
        socket.broadcast.emit('message', msg);

        // Simulate bot response
        setTimeout(() => {
            const botResponse = {
                user: 'Bot',
                message: getBotResponse(msg.message)
            };
            io.emit('message', botResponse);
        }, 1000);
    });
});

function getBotResponse(userMessage) {
     // custom data
    if (userMessage.includes('hello')) return 'Hi there! How can I help you today?';
    if (userMessage.includes('help')) return 'Sure, what do you need help with?';
    if(userMessage.includes('bye')) return "Have a Goodday sir";
    return 'Sorry, I didn\'t understand that. Can you please rephrase?';
}
