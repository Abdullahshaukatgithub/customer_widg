const socket = io();

let textarea = document.querySelector('#textarea');
let messageArea = document.querySelector('.message__area');
let userName = 'User'; // Default username

textarea.addEventListener('keyup', (e) => {
    if (e.key === 'Enter' && e.target.value.trim()) {
        sendMessage(e.target.value);
        textarea.value = ''; // Clear the input after sending
    }
});

function sendMessage(message) {
    const msg = {
        user: userName,
        message: message.trim()
    };

    // Append the outgoing message to the chat
    appendMessage(msg, 'outgoing');

    // Emit the message to the server
    socket.emit('message', msg);
}

function appendMessage(msg, type) {
    const mainDiv = document.createElement('div');
    mainDiv.classList.add('message', type);

    const markup = `
        <h4>${msg.user}</h4>
        <p>${msg.message}</p>
    `;

    mainDiv.innerHTML = markup;
    messageArea.appendChild(mainDiv);
    messageArea.scrollTop = messageArea.scrollHeight;
}

// Listen for incoming messages from the server (bot's response)
socket.on('message', (msg) => {
    if (msg.user !== userName) { // Ensure only the bot's messages are treated as incoming
        appendMessage(msg, 'incoming');
    }
});
